# Slow Hands (Fabric, Minecraft 1.21.11)

A client-side Fabric mod that makes the hand-swing animation noticeably slower by extending its duration to 24 game ticks (about 1.2 seconds). It does not change attack cooldowns, server tick rate, or actual combat reach/damage; it is a visual animation change.

## Build

Requires Java 21 and Gradle (or a Gradle wrapper). From this directory run:

```sh
gradle build
```

The compiled mod will be at `build/libs/slowhands-1.0.0.jar`.

## Install

1. Install Fabric Loader for Minecraft Java 1.21.11.
2. Put `slowhands-1.0.0.jar` in your Minecraft `mods` folder.
3. Launch the Fabric profile. This is client-only; install it on the client, not the server.

## Adjusting the speed

Edit `SLOW_HANDS_SWING_TICKS` in `LivingEntityMixin.java`. Higher values slow the swing further; lower values make it faster. Rebuild after changing it.

## Notes

This project uses Yarn named mappings and a Mixin injection into `LivingEntity#getHandSwingDuration`. It is source/build-project delivery; a compiled JAR must be produced with Gradle.
