package com.zeki.slowhands.mixin;

import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Changes the animation duration used when a living entity swings its hand. */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    /** Vanilla is normally around 6 ticks; 24 ticks makes the motion visibly slower. */
    private static final int SLOW_HANDS_SWING_TICKS = 24;

    @Inject(method = "getHandSwingDuration", at = @At("RETURN"), cancellable = true)
    private void slowhands$extendSwingDuration(CallbackInfoReturnable<Integer> cir) {
        cir.setReturnValue(SLOW_HANDS_SWING_TICKS);
    }
}
